import java.io.File;
import java.io.FileNotFoundException;

public abstract class Book implements IBook{

    public StringBuilder lineUpSpaces(String input, int chars){
        int i = 0;
        StringBuilder spaces = new StringBuilder();
        do {
            spaces.append(" ");
        }while (i++ < chars - input.length());
        return spaces;
    }

    File booklist = new File("booklist");
    @Override
    public void showBookInfo() throws FileNotFoundException {
        FileIO.read(booklist);
        while(FileIO.fileReader.hasNextLine()){
            System.out.println(FileIO.fileReader.nextLine());
        }
    }
}
