import java.io.IOException;

public class StudyBook extends Book{
    public static int maxReturnDays = 10;

    public void addStudy(String inputs []) throws IOException {
        FileIO.write("booklist","\n" + inputs[1] + lineUpSpaces(inputs[1],30) +
                inputs[2] + lineUpSpaces(inputs[2],30) + inputs[3] + lineUpSpaces(inputs[3],18)
                + "Ders Kitabı       " + maxReturnDays + " Gün");
        System.out.println("Succesfully added study book");
    }
}
