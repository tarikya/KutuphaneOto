import java.io.IOException;
import java.util.Scanner;

public class Register {
    Scanner scan = new Scanner(System.in);

    public Register() throws IOException {
    }


    public void menu() throws IOException {
        System.out.print("new username: ");
        String userID = scan.nextLine();
        System.out.print("new password: ");
        String password = scan.nextLine();
        FileIO.write("loginfile","\n"+userID+","+password);
    }
}
