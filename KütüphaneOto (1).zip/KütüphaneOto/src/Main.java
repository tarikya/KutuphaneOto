import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        Register register = new Register();
        LoginPage loginPage = new LoginPage();
        System.out.println("\n" +
                "█░░ █ █▄▄ █▀█ ▄▀█ █▀█ █▄█   ▄▀█ █░█ ▀█▀ █▀█ █▀▄▀█ ▄▀█ ▀█▀ █ █▀█ █▄░█\n" +
                "█▄▄ █ █▄█ █▀▄ █▀█ █▀▄ ░█░   █▀█ █▄█ ░█░ █▄█ █░▀░█ █▀█ ░█░ █ █▄█ █░▀█");
                    //ASCII ART COPY-PASTE
        System.out.println("Welcome to terminal library automation system.\n" +
                "Authors: Ahmet Faruk Sarıömeroğlu - Mehmed Tarık Yaraşır");
        System.out.println("Type \"help\" to see commands.");
        System.out.println();
        String input;
        while(true) {
            System.out.print("user@main: > ");
            input = scan.nextLine();
            switch (input) {
                case "help":
                    System.out.println("    login\n"+
                                       "    register\n"+
                                       "    exit");
                    break;
                case "login":
                    loginPage.menu();
                    break;
                case "register":
                    register.menu();
                    break;
                case "exit":
                    System.out.println("Goodbye.");
                    return;
                default:
                    System.out.println(input + ": command not found.");
                    break;
            }
        }
    }
}
