import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class WelcomePage {
    Scanner scan = new Scanner(System.in);
    WelcomePage(String username) throws Exception {
        System.out.println();
        File file = new File(username);
        boolean result = file.createNewFile();
        if (result){
            FileIO.write(username,"\nİsim                           Yazar            " +
                    "              Sayfa Sayısı       Tür               Max ödünç süresi\n");
            System.out.println("Account initialized.");
        }
        System.out.println("Welcome " + username + ".");
        if (username.equals("admin")) {
            adminMenu();
        }
        else
            menu(username);
    }


    Novel novel = new Novel();
    StudyBook study = new StudyBook();
    String[] inputs;
    String tempUsername, tempPassword;
    FileWriter write;

    private void adminMenu() throws Exception {
        while (true) {
            System.out.print("admin@lib: > ");
            inputs = scan.nextLine().split(" -");
            switch (inputs[0]) {
                case "help":
                    System.out.println("    booklist\n" +//done
                            "    addnovel -[name] -[author] -[pages]\n" +//done
                            "    addstudy -[name] -[author] -[pages]\n" +//done
                            "    userlist\n"+//done
                            "    ban -[username]\n" +//done
                            "    unbanall\n"+//done
                            "    bannedusers\n"+//done
                            "    logout");//done
                    break;
                case "booklist":
                    novel.showBookInfo();
                    break;
                case "addnovel":
                    if (inputs.length == 4)
                        novel.addNovel(inputs);
                    else
                        System.out.println("Wrong command type.");
                    break;
                case "addstudy":
                    if (inputs.length == 4)
                        study.addStudy(inputs);
                    else
                        System.out.println("Wrong command type.");
                    break;
                case "ban":
                    if (!inputs[1].equals("admin")){
                        FileIO.write("banned","\n"+inputs[1]);
                        System.out.println("Succesfully banned "+inputs[1]+".");
                    }
                    else
                        System.out.println("You can not ban admin.");
                    break;
                case "unbanall":
                     write = new FileWriter("banned",false);
                     write.write("");
                     System.out.println("All users unbanned.");
                    break;
                case "userlist":
                        FileIO.read(new File("loginfile"));
                        FileIO.fileReader.useDelimiter("[,\n]");

                        while(FileIO.fileReader.hasNext()){

                            tempUsername = FileIO.fileReader.next();
                            tempPassword = FileIO.fileReader.next();
                            if (!tempUsername.equals("admin"))
                                System.out.println(tempUsername);
                        }
                    FileIO.fileReader.close();
                    break;
                case"bannedusers":
                    FileIO.read(new File("banned"));
                    if (!FileIO.fileReader.hasNext()){
                        System.out.println("No banned users.");
                    }
                    else{
                        while(FileIO.fileReader.hasNext()){
                            System.out.println(FileIO.fileReader.nextLine());
                        }
                    }
                    break;
                case "logout":
                    return;
                default:
                    System.out.println(inputs[0] + ": command not found.");
                    break;
            }
        }
    }

    String borrowingBook;
    boolean borrowed = false;
    private void menu(String username) throws IOException {
        while (true){
            System.out.print(username.toLowerCase() + "@lib: > ");
            inputs = scan.nextLine().split(" -");
            switch (inputs[0]){
                case "help":
                    System.out.println("    booklist\n" +//done
                                       "    borrow -[first word of name]\n" +//done
                                       "    mybooks\n" +//done
                                       "    returnall\n" +//done
                                       "    logout");//done
                    break;
                case "booklist":
                    novel.showBookInfo();
                    System.out.println("\n");
                    break;
                case "borrow":
                    FileIO.read(new File("booklist"));
                    while(FileIO.fileReader.hasNext()){
                        if (FileIO.fileReader.next().equals(inputs[1])){
                            borrowingBook = "\n" + inputs[1] + FileIO.fileReader.nextLine();
                            FileIO.write(username,borrowingBook);
                            System.out.println("Succesfully borrowed book.");
                            borrowed = true;
                            break;
                        }
                    }
                    if (!borrowed)
                        System.out.println("Could not find the book.");
                    break;
                case "mybooks":
                    FileIO.read(new File(username));
                    while(FileIO.fileReader.hasNextLine()){
                        System.out.println(FileIO.fileReader.nextLine());
                    }
                    System.out.println("\n");
                    break;
                case "returnall":
                    write = new FileWriter(username,false);
                    FileIO.write(username,"\nİsim                           Yazar            " +
                            "              Sayfa Sayısı       Tür               Max ödünç süresi\n");
                    System.out.println("All books returned.");
                    break;
                case "logout":
                    return;
                default:
                    System.out.println(inputs[0]+": command not found.");
                    break;
            }
        }
    }
}
