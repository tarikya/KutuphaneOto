import java.io.FileNotFoundException;

public interface IBook {
    StringBuilder lineUpSpaces(String input, int chars);
    void showBookInfo() throws FileNotFoundException;
}
