import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LoginPage {
    Scanner scan = new Scanner(System.in);
    String username, password;
    String tempUsername = "", tempPassword = "";
    File loginfile = new File("loginfile");

    public LoginPage() throws FileNotFoundException {
    }

    StringBuilder banned = new StringBuilder();
    public void menu() throws Exception {
        System.out.print("username: ");
        username = scan.next();
        System.out.print("password: ");
        password = scan.next();
        FileIO.read(new File("banned"));
        while(FileIO.fileReader.hasNext()){
            if (FileIO.fileReader.next().equals(username)){
                System.out.println("This user has been banned.");
                return;
            }
        }

        if (verify(username,password)){
                new WelcomePage(username);
        }
        else
            System.out.println("Wrong account details.");
    }

    private boolean verify(String username, String password) throws FileNotFoundException {
        FileIO.read(loginfile);
        FileIO.fileReader.useDelimiter("[,\n]");

        while(FileIO.fileReader.hasNext()){
            tempUsername = FileIO.fileReader.next();
            tempPassword = FileIO.fileReader.next();

            if (tempUsername.trim().equals(username.trim()) && tempPassword.trim().equals(password.trim())){
                FileIO.fileReader.close();
                return true;
            }
        }
        FileIO.fileReader.close();
        return false;
    }
}
