import java.io.*;
import java.util.Scanner;

public class FileIO {
    public static FileWriter writer;
    public static Scanner fileReader;

    public static void write(String filename, String writeThis) throws IOException {
        writer = new FileWriter(filename, true);
        writer.write(writeThis);
        writer.close();
    }

    public static void read(File filename) throws FileNotFoundException {
        fileReader = new Scanner(filename);
    }

    public static void replaceLines(String willReplaceThisLine, String writeThis) {
        try {
            // input the (modified) file content to the StringBuffer "input"
            BufferedReader fileReader = new BufferedReader(new FileReader("amk"));
            StringBuilder inputBuffer = new StringBuilder();
            String line;

            while ((line = fileReader.readLine()) != null) {
                if (line.equals(willReplaceThisLine))
                    line = writeThis; // replace the line here
                inputBuffer.append(line);
                inputBuffer.append('\n');
            }
            fileReader.close();

            // write the new string with the replaced line OVER the same file
            FileOutputStream fileOut = new FileOutputStream("amk");
            fileOut.write(inputBuffer.toString().getBytes());
            fileOut.close();

        } catch (Exception e) {
            System.out.println("Problem reading file.");
        }
    }









   /* static StringBuilder stringRam = new StringBuilder();
    public static void deleteFile(String filename, File file, String lineToDelete) throws IOException {
        fileReader = new Scanner(file);
        writer = new FileWriter(filename,true);
        while (fileReader.hasNext()){
            if (!Objects.equals(fileReader.nextLine(), lineToDelete)){
                stringRam.append(fileReader.next());
            }
        }
        File f = new File(filename);
        fileReader.close();

        writer.write(stringRam.toString());
        writer.close();

        System.out.println("User banned.");
    }*/





}