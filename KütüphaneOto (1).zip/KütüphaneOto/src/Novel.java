import java.io.IOException;

public class Novel extends Book{
    public static int maxReturnDays = 15;

    public void addNovel(String inputs []) throws IOException {
        FileIO.write("booklist","\n" + inputs[1] + lineUpSpaces(inputs[1],30) +
                inputs[2] + lineUpSpaces(inputs[2],30) + inputs[3] + lineUpSpaces(inputs[3],18)
                + "Roman             " + maxReturnDays + " Gün");
        System.out.println("Succesfully added novel.");
    }
}